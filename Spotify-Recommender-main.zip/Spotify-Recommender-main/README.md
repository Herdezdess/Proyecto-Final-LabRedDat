﻿# Recomendador de canciones de spotify
Aplicacion de un sistema recomendador utilizando KNN

Como correr el proyecto localmente

Utiliza el comando pip install -r requirements.txt para instalar todo lo necesario para correr el proyecto localmente

Si necesitas una explicacion mas a profundidad acerca este proyecto puedes consultar mi articulo de medium
https://medium.com/@jesus.pesqueira98/recomendador-de-canciones-de-spotify-usando-knn-k-nearest-neighbors-738c54453f46


